
How to build and run this application:
  (The location of the junit jar file will vary on your machine, or may need to be downloaded.)

javac -cp /Applications/IntelliJ\ IDEA.app/Contents/lib/junit-4.12.jar *.java
java -cp /Applications/IntelliJ\ IDEA.app/Contents/lib/junit-4.12.jar -cp . Game
