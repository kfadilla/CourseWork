public class Triple {
    Double a;
    Double b;
    Double c;
    public Triple(Double a, Double b, Double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
