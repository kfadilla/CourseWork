# Pre-lecture: hashtables with separate chaining

This assignment is about hashtables with separate chaining, as described
in the lecture and textbook. Your task is to implement the `put` and 
`remove` methods, as well as the `findEnty` helper function.