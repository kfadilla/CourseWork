# Pre-lecture Assignment on QuickSort

Change the implementation of `quicksort` to use Median-of-Three partitioning,
as described in the textbook. That is, to choose the pivot, pick the median
of the first, middle, and last elements of the current range.