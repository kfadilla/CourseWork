# Pre-lecture assignment about Graphs

The objects of this assignment is to complete an
implementation of the `AdjacencyList` class in the
file `src/graphs/AdjacencyList.java`.