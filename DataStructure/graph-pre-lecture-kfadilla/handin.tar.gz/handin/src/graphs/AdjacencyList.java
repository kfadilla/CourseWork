package graphs;
import sequences.*;

import java.util.Iterator;

/**
 * TODO
 *
 * Complete the AdjacencyList class, implementing all of the
 * methods needed for the Graph interface and
 * finish the constructor.
 *
 */
public class AdjacencyList implements Graph<Integer> {
    Array<SLinkedList<Integer>> adjacent;


    public AdjacencyList(int num_vertices) {
        adjacent = new Array<SLinkedList<Integer>>(num_vertices, null);
        for (int i = 0; i != num_vertices; ++i){
            adjacent.set(i, new SLinkedList<>());
        }
    }

    public void addEdge(Integer source,Integer target) {
        adjacent.get(source).insert_front(target);
    }

    public Sequence<Integer> vertices(){
        SLinkedList<Integer> ret = new SLinkedList<>();
        Iter iter = ret.begin();
        while (!iter.equals(ret.end())){
            for (int i = 0; i != this.numVertices(); i++){
                iter.set(i);
                iter.advance();
            }
        }
        return ret;
    }

    public Sequence<Integer> adjacent(Integer source){
        return adjacent.get(source);
    }

    public int numVertices(){
        return adjacent.size();
    }
}
